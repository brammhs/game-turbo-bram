TurboPop - cara jadi APK

1. Pasang Android Studio (gratis) di PC/laptop.
2. File > Open > pilih folder TurboPop ini. Tunggu "Gradle sync" selesai (butuh internet).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK ada di: app/build/outputs/apk/debug/app-debug.apk
5. Kirim APK ke HP, install (izinkan "install dari sumber tidak dikenal").

Setelah install, buka TurboPop dan tekan tombol 1, 2, 3, lalu NYALAKAN.

Agar jendela mengambang bisa jalan (Realme C63):
- Pengaturan > Tentang ponsel > ketuk Nomor Build 7 kali
- Opsi Pengembang > aktifkan "Aktifkan jendela bentuk bebas" dan "Paksa aktivitas agar dapat diubah ukurannya", lalu restart HP
- Pengaturan > Baterai > TurboPop > "Tidak dibatasi" (supaya tidak dimatikan sistem)
