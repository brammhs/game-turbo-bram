package com.turbopop

import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile
        var instance: OverlayService? = null
        private const val CHANNEL = "turbopop"
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var menu: View? = null
    private var popup: View? = null
    private val removePopupRunnable = Runnable { removePopup() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        showBubble()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removePopup()
        hideMenu()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        instance = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "TurboPop", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("TurboPop aktif")
            .setContentText("Bubble mengambang berjalan")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(w: Int, h: Int, focusable: Boolean = false): WindowManager.LayoutParams {
        val flags = if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        return WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
    }

    // ---------- Bubble ----------

    private fun showBubble() {
        val size = dp(52)
        val v = TextView(this)
        v.text = "T"
        v.setTextColor(Color.WHITE)
        v.textSize = 20f
        v.gravity = Gravity.CENTER
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xE6FF5722.toInt())
        }

        val lp = overlayParams(size, size)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = dp(200)
        bubbleLp = lp

        var startX = 0f
        var startY = 0f
        var origX = 0
        var origY = 0
        var moved = false

        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX
                    startY = e.rawY
                    origX = lp.x
                    origY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - startX).toInt()
                    val dy = (e.rawY - startY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = origX + dx
                        lp.y = origY + dy
                        wm.updateViewLayout(v, lp)
                        if (menu != null) hideMenu()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleMenu()
                }
            }
            true
        }

        wm.addView(v, lp)
        bubble = v
    }

    // ---------- Menu ----------

    private fun toggleMenu() {
        if (menu != null) hideMenu() else showMenu()
    }

    private fun hideMenu() {
        menu?.let { runCatching { wm.removeView(it) } }
        menu = null
    }

    private fun showMenu() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        box.background = GradientDrawable().apply {
            setColor(0xF2222222.toInt())
            cornerRadius = dp(16).toFloat()
        }

        fun item(label: String, action: () -> Unit) {
            val tv = TextView(this)
            tv.text = label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 16f
            tv.setPadding(dp(16), dp(12), dp(16), dp(12))
            tv.setOnClickListener {
                hideMenu()
                action()
            }
            box.addView(tv)
        }

        item("WhatsApp") { launchFloating(waPackage()) }
        item("TikTok") { launchFloating(tiktokPackage()) }
        item("Matikan TurboPop") { stopSelf() }

        val menuWidth = dp(190)
        val lp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.TOP or Gravity.START
        val screenW = resources.displayMetrics.widthPixels
        lp.x = if (bubbleLp.x + dp(60) + menuWidth > screenW) {
            (bubbleLp.x - menuWidth).coerceAtLeast(0)
        } else {
            bubbleLp.x + dp(60)
        }
        lp.y = bubbleLp.y

        wm.addView(box, lp)
        menu = box
    }

    // ---------- Popup notifikasi ----------

    fun showPopup(pkg: String, judul: String, isi: String) {
        handler.post {
            removePopup()
            val label = if (pkg.startsWith("com.whatsapp")) "WhatsApp" else "TikTok"

            val tv = TextView(this)
            tv.text = "$label - $judul\n$isi"
            tv.setTextColor(Color.WHITE)
            tv.textSize = 14f
            tv.maxLines = 3
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setPadding(dp(16), dp(12), dp(16), dp(12))
            tv.background = GradientDrawable().apply {
                setColor(0xF2222222.toInt())
                cornerRadius = dp(14).toFloat()
            }
            tv.setOnClickListener {
                removePopup()
                launchFloating(pkg)
            }

            val width = resources.displayMetrics.widthPixels - dp(24)
            val lp = overlayParams(width, WindowManager.LayoutParams.WRAP_CONTENT)
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = dp(40)

            wm.addView(tv, lp)
            popup = tv
            handler.postDelayed(removePopupRunnable, 6000)
        }
    }

    private fun removePopup() {
        handler.removeCallbacks(removePopupRunnable)
        popup?.let { runCatching { wm.removeView(it) } }
        popup = null
    }

    // ---------- Buka aplikasi sebagai jendela mengambang ----------

    private fun firstInstalled(vararg pkgs: String): String =
        pkgs.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null } ?: pkgs.first()

    private fun waPackage() = firstInstalled("com.whatsapp", "com.whatsapp.w4b")

    // TikTok Indonesia biasanya memakai paket "trill"
    private fun tiktokPackage() = firstInstalled("com.ss.android.ugc.trill", "com.zhiliaoapp.musically")

    private fun launchFloating(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            Toast.makeText(this, "Aplikasi tidak ditemukan: $pkg", Toast.LENGTH_SHORT).show()
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.92).toInt()
        val h = (dm.heightPixels * 0.55).toInt()
        val left = (dm.widthPixels - w) / 2
        val top = dm.heightPixels - h - dp(24)

        try {
            val opts = ActivityOptions.makeBasic()
            opts.setLaunchBounds(Rect(left, top, left + w, top + h))
            // Mode freeform (5). API ini tersembunyi, jadi dibungkus try-catch.
            runCatching {
                ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                    .invoke(opts, 5)
            }
            startActivity(intent, opts.toBundle())
        } catch (e: Exception) {
            // Cadangan: buka biasa (layar penuh)
            startActivity(intent)
        }
    }
}
