package com.turbopop

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    private val targets = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in targets) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras
        val judul = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val isi = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        OverlayService.instance?.showPopup(sbn.packageName, judul, isi)
    }
}
