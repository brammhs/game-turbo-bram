package com.turbopop

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun addText(t: String, size: Float = 14f): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.textSize = size
            tv.setPadding(0, pad / 2, 0, pad / 2)
            root.addView(tv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            return tv
        }

        fun addButton(t: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { onClick() }
            root.addView(b, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        addText("TurboPop", 26f)
        addText("Bubble mengambang untuk membuka WhatsApp / TikTok di atas game, plus pop-up pesan masuk.")
        status = addText("")

        addButton("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }
        addButton("2. Izinkan akses notifikasi") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        addButton("3. Izinkan notifikasi (Android 13+)") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
        addButton("NYALAKAN TurboPop") {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, OverlayService::class.java))
            } else {
                status.text = "Izin 'tampil di atas aplikasi lain' belum aktif."
            }
        }
        addButton("MATIKAN TurboPop") {
            stopService(Intent(this, OverlayService::class.java))
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val overlay = Settings.canDrawOverlays(this)
        val listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        val notifAccess = listeners.contains(packageName)
        val postNotif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        status.text = "Status izin:\n" +
            "- Di atas aplikasi lain: ${if (overlay) "OK" else "BELUM"}\n" +
            "- Akses notifikasi: ${if (notifAccess) "OK" else "BELUM"}\n" +
            "- Tampil notifikasi: ${if (postNotif) "OK" else "BELUM"}"
    }
}
